# 1.0.1 (2017-05-31)

## Fixed
- #21: Fix generation of alphanumeric strings (thanks @dbarranco)

# 1.0.0 (2014-04-30)

- Initial release.
