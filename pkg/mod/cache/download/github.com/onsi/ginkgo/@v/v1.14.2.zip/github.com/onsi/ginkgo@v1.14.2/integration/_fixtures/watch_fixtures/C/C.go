package C

func DoIt() string {
	return "done!"
}
