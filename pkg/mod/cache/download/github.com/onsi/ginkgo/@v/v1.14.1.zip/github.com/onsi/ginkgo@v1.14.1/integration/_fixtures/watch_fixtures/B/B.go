package B

import "$ROOT_PATH$/C"

func DoIt() string {
	return C.DoIt()
}
