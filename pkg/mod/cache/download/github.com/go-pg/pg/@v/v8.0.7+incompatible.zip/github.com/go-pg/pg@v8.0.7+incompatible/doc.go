/*
Package github.com/go-pg/pg implements a PostgreSQL client.
*/
package pg
