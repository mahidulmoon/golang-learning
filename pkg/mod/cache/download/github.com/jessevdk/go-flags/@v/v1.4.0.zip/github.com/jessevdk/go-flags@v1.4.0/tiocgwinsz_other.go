// +build !darwin,!freebsd,!netbsd,!openbsd,!linux

package flags

const (
	tIOCGWINSZ = 0
)
