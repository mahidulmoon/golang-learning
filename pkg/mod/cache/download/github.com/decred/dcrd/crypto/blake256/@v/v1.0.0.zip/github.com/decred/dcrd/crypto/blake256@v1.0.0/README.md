Package blake256
================

Package blake256 implements BLAKE-256 and BLAKE-224 hash functions (SHA-3
candidate).

Originally from `github.com/teknico/blake256`.
