# CustomArgs

* [With Mail Helper Class](custom-args-with-mailer-helper.md)
* [Without Mail Helper Class](custom-args-without-mailer-helper.md)