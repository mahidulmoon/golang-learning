# Substitutions

* [With Mail Helper Class](substitutions-with-mailer-helper.md)
* [Without Mail Helper Class](substitutions-without-mailer-helper.md)