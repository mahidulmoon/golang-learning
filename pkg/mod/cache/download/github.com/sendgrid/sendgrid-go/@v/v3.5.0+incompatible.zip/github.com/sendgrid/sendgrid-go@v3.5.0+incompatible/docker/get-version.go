package main

import (
	"fmt"
	"github.com/sendgrid/sendgrid-go"
)

func main() {
	fmt.Println(sendgrid.Version)
}
