package mailgun

// Version of current release
const Version = "3.6.1"
